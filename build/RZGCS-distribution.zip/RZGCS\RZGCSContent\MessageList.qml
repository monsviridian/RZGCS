import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: messageList
    color: "#1E1E1E"
    border.color: "#404040"
    border.width: 1
    
    property var messageManager: null
    property int maxVisibleMessages: 8
    
    // Header
    Rectangle {
        id: header
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        height: 30
        color: "#2C2C2C"
        border.color: "#404040"
        border.width: 0
        
        RowLayout {
            anchors.fill: parent
            anchors.margins: 5
            
            Label {
                text: "Recent Messages"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
            
            Item {
                Layout.fillWidth: true
            }
            
            Label {
                text: messageManager ? messageManager.messages.length + " messages" : "0 messages"
                color: "#CCCCCC"
                font.pixelSize: 12
            }
        }
    }
    
    // Message List
    ListView {
        id: listView
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 5
        
        model: messageManager ? messageManager.messages : []
        
        delegate: Rectangle {
            width: listView.width
            height: messageText.height + 20
            color: index % 2 === 0 ? "#252525" : "#2A2A2A"
            
            RowLayout {
                anchors.fill: parent
                anchors.margins: 5
                spacing: 8
                
                // Type indicator
                Rectangle {
                    Layout.preferredWidth: 4
                    Layout.fillHeight: true
                    color: messageManager ? messageManager.getTypeColor(modelData.type) : "#2196F3"
                }
                
                // Timestamp
                Label {
                    text: modelData.timestamp
                    color: "#888888"
                    font.pixelSize: 10
                    Layout.preferredWidth: 60
                }
                
                // Type label
                Label {
                    text: messageManager ? messageManager.getTypeString(modelData.type) : "INFO"
                    color: messageManager ? messageManager.getTypeColor(modelData.type) : "#2196F3"
                    font.pixelSize: 10
                    font.bold: true
                    Layout.preferredWidth: 50
                }
                
                // Message text
                Label {
                    id: messageText
                    text: modelData.text
                    color: "white"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }
                
                // Remove button
                Button {
                    text: "×"
                    Layout.preferredWidth: 20
                    Layout.preferredHeight: 20
                    visible: false
                    
                    background: Rectangle {
                        color: parent.pressed ? "#F44336" : "#404040"
                        radius: 10
                    }
                    
                    contentItem: Text {
                        text: parent.text
                        color: "white"
                        font.pixelSize: 14
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    
                    onClicked: {
                        if (messageManager) {
                            messageManager.removeMessage(index)
                        }
                    }
                }
            }
            
            // Hover effect
            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                onEntered: {
                    parent.color = "#303030"
                    removeButton.visible = true
                }
                onExited: {
                    parent.color = index % 2 === 0 ? "#252525" : "#2A2A2A"
                    removeButton.visible = false
                }
            }
        }
        
        // Scroll indicator
        ScrollBar.vertical: ScrollBar {
            active: true
            policy: ScrollBar.AsNeeded
        }
    }
    
    // Empty state
    Rectangle {
        anchors.fill: listView
        color: "#1E1E1E"
        visible: !messageManager || messageManager.messages.length === 0
        
        ColumnLayout {
            anchors.centerIn: parent
            spacing: 10
            
            Label {
                text: "No messages yet"
                color: "#888888"
                font.pixelSize: 16
                Layout.alignment: Qt.AlignHCenter
            }
            
            Label {
                text: "Messages will appear here when events occur"
                color: "#666666"
                font.pixelSize: 12
                Layout.alignment: Qt.AlignHCenter
            }
        }
    }
} 