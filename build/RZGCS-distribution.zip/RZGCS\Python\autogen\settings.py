
url = "RZGCSContent/App.qml"
import_paths = [
    ".",
]
